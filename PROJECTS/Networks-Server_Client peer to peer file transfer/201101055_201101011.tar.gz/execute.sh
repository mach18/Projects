rm final
gcc -w -o final 201101055_201101011.c -lssl -lcrypto
